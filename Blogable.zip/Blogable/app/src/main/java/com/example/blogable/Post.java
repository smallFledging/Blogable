package com.example.blogable;

import com.google.firebase.database.ServerValue;

public class Post {

    private String postKey;
    private String message;
    private String uid;
    private Object timeStamp;

    public Post(String message, String uid) {
        this.message = message;
        this.uid = uid;
        this.timeStamp = ServerValue.TIMESTAMP;
    }

    public Post(){

    }

    public String getPostKey() {
        return postKey;
    }

    public void setPostKey(String postKey) {
        this.postKey = postKey;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Object getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Object timeStamp) {
        this.timeStamp = timeStamp;
    }
}
